from pathlib import Path
from PIL import Image

for jpg_file in Path(".").rglob("*.jpg"):
    png_file = jpg_file.with_suffix(".png")

    with Image.open(jpg_file) as img:
        img.save(png_file)

    jpg_file.unlink()  # supprime le .pgm

print("Terminé.")