from pathlib import Path
from PIL import Image

for pgm_file in Path(".").rglob("*.pgm"):
    png_file = pgm_file.with_suffix(".png")

    with Image.open(pgm_file) as img:
        img.save(png_file)

    pgm_file.unlink()  # supprime le .pgm

    print(f"Converti : {pgm_file}")

print("Terminé.")